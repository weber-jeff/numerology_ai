"""
numerology_core.py

Core numerology calculations:
- Life Path Number (component-wise reduction)
"""

def reduce_number(n: int) -> int:
    """
    Reduces a number by summing its digits until a single digit or master number (11, 22).
    """
    while n > 9 and n not in (11, 22):
        n = sum(int(d) for d in str(n))
    return n

def life_path_number(birthdate: str) -> int:
    """
    Calculate the Life Path Number using component-wise reduction from birthdate "DD/MM/YYYY".
    """
    day, month, year = birthdate.split('/')
    # Reduce each component
    day_sum = reduce_number(sum(int(d) for d in day))
    month_sum = reduce_number(sum(int(d) for d in month))
    year_sum = reduce_number(sum(int(d) for d in year))
    total = day_sum + month_sum + year_sum
    return reduce_number(total)

# Example usage
if __name__ == "__main__":
    birthdate = "08/05/1987"
    lp = life_path_number(birthdate)
    print(f"Life Path Number for {birthdate} is {lp}")
