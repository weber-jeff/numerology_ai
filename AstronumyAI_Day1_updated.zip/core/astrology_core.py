"""
astrology_core.py

Basic astrology calculations:
- Sun sign determination based on birthdate (Western Zodiac)
- Moon phase calculation (approximate)
"""

ZODIAC_SIGNS = [
    ("Capricorn", (1, 20)), ("Aquarius", (2, 19)), ("Pisces", (3, 21)),
    ("Aries", (4, 20)), ("Taurus", (5, 21)), ("Gemini", (6, 21)),
    ("Cancer", (7, 23)), ("Leo", (8, 23)), ("Virgo", (9, 23)),
    ("Libra", (10, 23)), ("Scorpio", (11, 22)), ("Sagittarius", (12, 22)),
    ("Capricorn", (12, 31))
]

def sun_sign(birthdate: str) -> str:
    day, month, _ = map(int, birthdate.split('/'))
    for sign, (m, d) in ZODIAC_SIGNS:
        if (month, day) <= (m, d):
            return sign
    return "Capricorn"

if __name__ == "__main__":
    birthdate = "08/05/1987"
    sign = sun_sign(birthdate)
    print(f"Sun sign for {birthdate} is {sign}")
